# IO-Axure-html Inżynieria oprogramowania

Każdy zakłada konto na GitHub, tworzy repozytorium (main i 2 gałęzie) i kopiuje swój projekt z axure//html.
Udostępnia koledze z pary i modyfikuje jego jakiś plik.
Zmiany mają być zatwierdzone.

- 1 https://github.com/
- 2 https://docs.github.com/en/get-started/quickstart
